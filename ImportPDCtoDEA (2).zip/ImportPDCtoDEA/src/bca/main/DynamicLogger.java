/**
 * <p>Title: Dynamic Log4j Appender</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2011</p>
 *
 * <p>Company: PT. Bank Central Asia Tbk.</p>
 *
 * @author Mario Sukiman
 * @version 1.0
 */
package bca.main;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.spi.ErrorCode;

public class DynamicLogger extends RollingFileAppender {

    public DynamicLogger() {
    }

    public DynamicLogger(Layout layout, String filename,
            boolean append) throws IOException {
        super(layout, filename, append);
    }

    public DynamicLogger(Layout layout, String filename)
            throws IOException {
        super(layout, filename);
    }

    public void activateOptions() {
        if (fileName != null) {
            try {
                fileName = getNewLogFileName();
                setFile(fileName, fileAppend, bufferedIO, bufferSize);
            } catch (Exception e) {
                errorHandler.error("Error while activating log options", e,
                        ErrorCode.FILE_OPEN_FAILURE);
            }
        }
    }

    private String getNewLogFileName() {
        if (fileName != null) {
            final String DOT = ".";
            final String HIPHEN = "_";
            final File logFile = new File(fileName);
            final String fileName = logFile.getName();
            String newFileName = "";
            java.util.Calendar now = java.util.Calendar.getInstance();
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyyMMdd");

            final int dotIndex = fileName.indexOf(DOT);
            if (dotIndex != -1) {
                // the file name has an extension. so, insert the time stamp
                // between the file name and the extension
                newFileName = sdf.format(now.getTime()) + HIPHEN + fileName.substring(0, dotIndex)
                        + DOT
                        + fileName.substring(dotIndex + 1);
            } else {
                // the file name has no extension. So, just append the timestamp
                // at the end.
                newFileName = sdf.format(now.getTime()) + HIPHEN + fileName.substring(0, dotIndex);
            }
            return logFile.getParent() + File.separator + newFileName;
        }
        return null;
    }
}
