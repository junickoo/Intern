/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bca.main;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
//import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author U065626
 */
public class ExtractMetadata {

    private static final Logger LOGGER_EM = Logger.getLogger(ExtractMetadata.class);
    private static final String SEPARATOR = System.getProperty("file.separator");

    private DataValidation dataValidation;

    private String docDate, docDueDate;
    private static int currentLine = 0;
    private static int successLine = 0;
    private static int failedLine = 0;

    private void writeFileReplace(String filePath, String line) {
        FileOutputStream outputStream = null;
        try {
//            outputStream = new FileOutputStream(filePath, true);
            outputStream = new FileOutputStream(filePath, false);
            byte[] strToBytes = line.getBytes();
            outputStream.write(strToBytes);
            outputStream.close();

        } catch (Exception ex) {
            System.out.println("Error Write File Replace " + ex.getMessage());
        } finally {

        }
    }

    private void writeFile(String filePath, String line) {
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(filePath, true);
            byte[] strToBytes = line.getBytes();
            outputStream.write(strToBytes);
            outputStream.close();

        } catch (Exception ex) {
            System.out.println("Error Write File " + ex.getMessage());
        } finally {

        }
    }

    private void insertDate(String restURLDocType, String accessKey, String secretKey, String docCategory, String docType, String curDate, Boolean isUserRek) throws Exception {
        HashMap<String, String> listDocTypes = new HashMap<>();
//        String accessKeyMetadata = Base64.getEncoder().encodeToString(accessKey.getBytes());
        final HttpResponse<JsonNode> response = Unirest.get(restURLDocType)
                .header("AUTHORIZATION", accessKey + ":" + secretKey)
                .asJson();
        JSONObject obj = response.getBody().getObject();
        JSONArray docTypes = obj.getJSONArray("output");
        for (int i = 0; i < docTypes.length(); i++) {
            JSONObject jsonObject = docTypes.getJSONObject(i);
            if (jsonObject.getString("category").equalsIgnoreCase(docCategory)) {
                listDocTypes.put(jsonObject.getString("document_type"), jsonObject.getString("input_date"));
            }
        }
        String inputDate = listDocTypes.getOrDefault(docType, "false");

        if (inputDate.equalsIgnoreCase("false")) {
            //if user rek -> dok type identitas can be inserted in dok rekening
            if (isUserRek) {
                docDate = curDate;
                docDueDate = "";
            } else {
                throw new Exception("Error - Document Type " + docType + " Not Found in DEA");
            }
        } else if (inputDate.equalsIgnoreCase("doc_due_date")) {
            if (!curDate.equals("") && !curDate.equals(" ") && !"".equals(curDate.trim())) {
                String[] splitDate = curDate.split("-");
                String day = splitDate[2];
                String month = splitDate[1];
                String year = splitDate[0];
                if (year.equals("9999")) {
                    if (!month.equals("12") || !day.equals("31")) {
                        curDate = "9999-12-31";
                    }
                }
            }else {
//                if (docCategory.equalsIgnoreCase("identitas")){
//                    throw new Exception("Error in Generate Date, Doc Due Date Cannot be Null for Identitas: " + docType);
                    throw new Exception("Error in Generate Date, Doc Due Date Cannot be Null for " + docType);
//                }
            }
            docDueDate = curDate;
            docDate = "";
        } else if (inputDate.equalsIgnoreCase("document_date")) {
            if (!curDate.equals("") && !curDate.equals(" ") && !"".equals(curDate.trim())) {
                String[] splitDate = curDate.split("-");
                String day = splitDate[2];
                String month = splitDate[1];
                String year = splitDate[0];
//                if (year.equals("9999")) {
//                    if (!month.equals("12") || !day.equals("31")) {
//                        curDate = "9999-12-31";
//                    }
//                }
            }
//            else{
//                if (docCategory.equalsIgnoreCase("identitas")){
//                    throw new Exception("Error in Generate Date, Doc Date Cannot be Null for Identitas: " + docType);
//                }
//            }
            docDate = curDate;
            docDueDate = "";
        } else {
            throw new Exception("Error - Document Type " + docType + " Not Found in DEA");
        }
    }

    public void readFolder(String directoryName, List<File> files, ConfigurationProperties props, Boolean isUserRek, DataValidation dataValidation) throws Exception {

        String localPath = "";
        String fileType = "";
        String cisNo = "";
        String accNo = "";
        String docCategory = "";
        String curDate = "";
        String docDesc = "";
        String branchCode = "";
        String custName = "";
        String productName = "";
        String boxNo = "";
        String docType = "";
        String docPath = "";
        docDate = docDueDate = "";
//        String tempCisNo = "";
//        String tempAccNo = "";
//        boolean isAccValid = true;
//        boolean isCisValid = true;

        Date stDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        File directory = new File(directoryName);
        if (!directory.exists()) {
            LOGGER_EM.error("Folder " + directory + " not exist");
            System.out.println("Folder " + directory + " not exist");
        }
        // Get all files from a directory.
        File[] fList = directory.listFiles();
        String newLine = "";

        if (fList != null) {
            for (File file : fList) {
                try {
                    if (file.isFile()) {
                        fileType = file.getName().substring(file.getName().lastIndexOf(".") + 1);
//                            check if file type should be ignored or not (not marked as currentLine and failedLine)
                        if (props.ignoreExtList.contains(fileType)) {
                            System.out.println(sdf.format(stDate) + " - Invalid File Extension - " + file.getAbsolutePath());
                            LOGGER_EM.error(sdf.format(stDate) + " - Invalid File Extension - " + file.getAbsolutePath());
                            continue;
                        }

                        files.add(file);
                        currentLine++;

//                            check file size
                        if (!dataValidation.checkFileSize(file.getAbsolutePath(), props.MAXSIZE)) {
                            throw new Exception("Error - File Size too Big: " + file.getAbsolutePath());
                        }

//                        start extraction from main folder
                        String folderStartPath = props.mainFolder.substring(props.mainFolder.lastIndexOf(SEPARATOR) + 1);
                        String[] word = file.getAbsolutePath().split(folderStartPath);
                        docPath = word[1];

                        String metadata[] = word[1].split(Pattern.quote(SEPARATOR));
                        docCategory = metadata[4].toUpperCase();

//                        rename OPERASIONAL to REKENING
                        if (docCategory.equalsIgnoreCase("operasional")) {
                            docCategory = "rekening";
                        }

//                            check num of subfolder = metadata length
                        if (!String.valueOf(metadata.length).equals(props.categoriesLength.get(docCategory.toLowerCase()))) {
                            LOGGER_EM.error(sdf.format(stDate) + " - Invalid Folder Path: " + file.getAbsolutePath());
                            System.out.println(sdf.format(stDate) + " - Invalid Folder Path: " + file.getAbsolutePath());
                            throw new Exception("Error - Invalid Folder Path: " + file.getAbsolutePath() + "\n");
                        }

                        branchCode = dataValidation.branchCodeChecker(metadata[1]);
                        boxNo = dataValidation.boxNumberChecker(metadata[2]);
//                        check CIS
                        cisNo = dataValidation.cisNoChecker(metadata[3], props.REST_URL_EAI, props.CLIENT_ID);
                        custName = dataValidation.getCustomerName(cisNo, props.REST_URL_EAI, props.CLIENT_ID);

                        if (!file.getName().split("\\.(?=[^\\.]+$)")[0].contains("_")) {
                            throw new Exception("File Name Invalid");
                        }
                        String[] fileName = file.getName().split("\\.(?=[^\\.]+$)")[0].split("_");
                        docType = fileName[0].trim();

//                            check if docType included in category document type list or not
                        dataValidation.checkDocType(props.REST_URL_DEA_DOCUMENTTYPE, props.ACCESS_KEY, props.SECRET_KEY, docType, docCategory, isUserRek);
//                            extracting metadata from filename
                        switch (fileName.length) {
                            case 3:
                                curDate = dataValidation.generateDate(fileName[1]);
                                docDesc = dataValidation.docDescChecker(fileName[2]);
                                break;
                            case 2:
                                if (dataValidation.isNumeric(fileName[1])) {
                                    if (fileName[1].length() == 8) {
                                        curDate = dataValidation.generateDate(fileName[1]);
                                        docDesc = "";
                                    } else {
                                        throw new Exception("Date Is Not 8 Digit");
                                    }
                                } else {
                                    docDesc = dataValidation.docDescChecker(fileName[1]);
                                    curDate = "";
                                }
                                break;
                            default:
                                docDesc = "";
                                curDate = "";
                                break;
                        }
                        // to get docDate and docDueDate variables
                        insertDate(props.REST_URL_DEA_DOCUMENTTYPE, props.ACCESS_KEY, props.SECRET_KEY, docCategory, docType, curDate, isUserRek);
//                        objName = dataValidation.changeObjName(props.REST_URL_DEA_DOCUMENTTYPE, props.ACCESS_KEY, props.SECRET_KEY, docCategory, docType, docDueDate, docDate, docDesc, isUserRek);
//                        objId = dataValidation.generateNewGuid();
                        localPath = file.getAbsolutePath();

//                        check if document needs account number metadata or not
                        accNo = dataValidation.accNoUsageChecker(docCategory, metadata[5], cisNo, props.REST_URL_EAI_CIS, props.CLIENT_ID, props.categoriesUsingAcc, props.categoriesUsingAccOpt);
                        docCategory = "DOKUMEN " + docCategory;

                        newLine = localPath + props.delimiter + fileType
                                + props.delimiter + cisNo + props.delimiter + accNo
                                + props.delimiter + docType + props.delimiter + docCategory
                                + props.delimiter + docDueDate + props.delimiter + docDate
                                + props.delimiter + docDesc + props.delimiter + branchCode
                                + props.delimiter + custName + props.delimiter + productName
                                + props.delimiter + boxNo;
                        writeFile(props.PROCESS_DIR + SEPARATOR + props.processFile, newLine + "\n");
                        LOGGER_EM.debug(sdf.format(stDate) + " - File " + docPath + " successfully extracted!");
                        System.out.println(sdf.format(stDate) + " - File " + docPath + " successfully extracted!");
                        successLine++;

//                            currentLine++;
                    } else if (file.isDirectory()) {
                        readFolder(file.getAbsolutePath(), files, props, isUserRek, dataValidation);
                    }
                } catch (ParseException x) {
                    LOGGER_EM.error(sdf.format(stDate) + " - Error Extracting Metadata on File '" + file.getAbsolutePath() + ": Unparsable Date");
                    writeFile(props.RESULT_FILE_ERROR, "File: " + file.getAbsolutePath() + ", Error Msg : - " + x.getMessage() + "\n");
                    failedLine++;
                    System.out.println("Error on Extracting Metadata. Exception: " + x.getMessage());

                } catch (Exception x) {
                    LOGGER_EM.error(sdf.format(stDate) + " - Error Extracting Metadata on File '" + file.getAbsolutePath());
                    writeFile(props.RESULT_FILE_ERROR, "File: " + file.getAbsolutePath() + ", Error Msg : - " + x.getMessage() + "\n");
                    failedLine++;
                    System.out.println("Error on Extracting Metadata. Exception: " + x.getMessage());
                }

            }
        }
    }

    public void extracting(ConfigurationProperties props) throws IOException, Exception {
//        System.out.println("USER_DIR: " + USER_DIR);
        Date startDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        SimpleDateFormat fileDateFormat = new SimpleDateFormat("dd_MM_yyyy");

        System.out.println(formatter.format(startDate) + " - Starting Extract Metadata..");
        LOGGER_EM.debug(formatter.format(startDate) + " - Starting Extract Metadata..");
        List fileList = new ArrayList();
        Boolean isUserRek = false;
        dataValidation = new DataValidation();

//        check authorization key
        if (!props.checkAuthorization()) {
            LOGGER_EM.error("Error - User Not Authorized: " + props.UDOMAIN + ":" + props.ACCESS_KEY + "\n");
            throw new Exception("Error - User Not Authorized: " + props.UDOMAIN + ":" + props.ACCESS_KEY + "\n");
        }

        //        check if user pdc or not
        if (props.checkUserRekening()) {
            isUserRek = true;
        }

        String lineHeader = "localpath;file_type;bca_cis_no;bca_acc_no;bca_doc_type;bca_doc_category;bca_doc_due_date;bca_doc_date;bca_doc_desc;bca_branch_code;bca_cust_name;bca_product_name;bca_box_no";
        writeFileReplace(props.PROCESS_DIR + SEPARATOR + props.processFile, lineHeader + "\n");

        readFolder(props.mainFolder, fileList, props, isUserRek, dataValidation);

        Date endDate = new Date();
        System.out.println(formatter.format(endDate) + " - Finish Extract Metadata..");
        System.out.println(formatter.format(endDate) + " - Total Existing File: " + currentLine + ", success: " + successLine + ", failed: " + failedLine);

        LOGGER_EM.debug(formatter.format(endDate) + " - Finish Extract Metadata..");
        LOGGER_EM.debug(formatter.format(endDate) + " - Total Existing File: " + currentLine + ", success: " + successLine + ", failed: " + failedLine);

        if (successLine < 1) {
            throw new Exception("No Files Extracted");
        }

//        return fileList.size();
    }

//    public static void main(String[] args) throws IOException {
//        Date startDate = new Date();
//        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//        System.out.println(formatter.format(startDate) + " - Starting Extract Metadata..");
//        List fileList = new ArrayList();
//        try {
//            properties = readProperties(CONFIG_PROPERTIES);
//            initConfigLocal(properties);
//            readRules();
//
//            String lineHeader = "dw_objid;localpath;urlpath;current_filename;original_filename;dw_obj_name;bca_cis_no;bca_acc_no;bca_doc_type;bca_doc_category;bca_doc_due_date;bca_doc_date;bca_doc_desc;bca_branch_code;bca_cust_name;bca_product_name;bca_box_no;dw_origid;version";
//            writeFile(RESULT_FILE_SUCCESS, lineHeader + "\n");
//
//            readFolder(processFolder, fileList);
//
//            Date endDate = new Date();
//            System.out.println(formatter.format(endDate) + " - Finish Extract Metadata..");
//            System.out.println("Total Existing File: " + fileList.size());
//
//        } catch (Exception x) {
////            LOGGER_UD.error("Error on Main Program on Line '" + currentLine + "', " + x.getMessage());
//            System.out.println("Error on Extracting Metadata. Exception: " + x);
//        }
////        return fileList.size();
//    }
}
