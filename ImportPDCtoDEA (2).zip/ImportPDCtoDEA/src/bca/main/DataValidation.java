/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bca.main;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author U065626
 */
public class DataValidation {

    public boolean isAccValid = true;
    public boolean isCisValid = true;
    public String tempAccNo = "";
    public String tempCisNo = "";

    public String generateNewGuid() {
        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
        return randomUUIDString;
    }

//    to be used on filename checker in ExtractMetadata
    public boolean isNumeric(String strNum) {
        return strNum.matches("-?\\d+(\\.\\d+)?");
    }

    public String paddingZero(String processNumber, int maxlength) {
        int currentNoLength = processNumber.length();
        int processNoLength = maxlength - currentNoLength;
        String paddingZero = "";

        for (int x = 0; x < processNoLength; x++) {
            paddingZero += "0";
        }

        String currentProcess = paddingZero + processNumber;
        return currentProcess;
    }

    public String paddingZeroString(String number) {
        String zeroAdd = "";
        for (int i = number.length(); i < 11; i++) {
            zeroAdd += "0";
        }
        return zeroAdd + number;
    }

    //return di excel dalam format Date
    public String paddingZeroDate(int date) {
        String newDate = String.valueOf(date);
        if (newDate.length() < 2) {
            newDate = String.format("%02d", date);
        }
        return newDate;
    }

    //date must exist
    public String checkDate(String curDate) throws Exception {
        if (!"".equals(curDate.trim())) {
            String[] date = curDate.split("-");
            int month = Integer.valueOf(date[1]);
            if (month > 12) {
//                curDate = date[0] + "-" + date[2] + "-" + date[1];
                throw new Exception("Date " + curDate + " Is Not Valid");
            }
        } else {
            curDate = "";
        }
        return curDate;
    }

    public boolean validateDate(String date) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
        sdf.setLenient(false);

        //if not valid, it will throw ParseException
        Date dateCur = sdf.parse(date);
        String valDate = sdf.format(dateCur);
//            System.out.println("curdate: " + dateCur);
//            System.out.println("valdate: " + valDate);
        return true;

    }

    //date must exist
    public String generateDate(String curDate) throws NumberFormatException, ParseException, Exception {
        //tanggal yg dibaca: DDMMYYYY
        if (!"".equals(curDate.trim())) {
            if (curDate.length() != 8) {
                throw new Exception("Date Is Not 8 Digit");
            } else {
                    int day = Integer.valueOf(curDate.substring(0, 2));
                    int month = Integer.valueOf(curDate.substring(2, 4));
                    int year = Integer.valueOf(curDate.substring(4));

                    if (day > 31 || day < 1 || month > 12 || month < 1 || year < 1500) {
                        throw new Exception("Date " + curDate + " Is Not Valid");
                    }

                    if (validateDate(curDate)) {
                        //format di DEA: YYYY-MM-dd
                        curDate = year + "-" + paddingZeroDate(month) + "-" + paddingZeroDate(day);
                    }
            }
        } else {
            curDate = "";
        }
        return curDate;
    }

    //to be changed
    public String changeObjName(String restURLDocType, String accessKey, String secretKey, String docCategory, String docType, String docDueDate, String docDate, String docDesc, Boolean isUserRek) throws Exception {
        String objNameNew = "";
        HashMap<String, String> listDocTypes = new HashMap<>();
        try {
            final HttpResponse<JsonNode> response = Unirest.get(restURLDocType)
                    .header("AUTHORIZATION", accessKey + ":" + secretKey)
                    .asJson();
            JSONObject obj = response.getBody().getObject();
            JSONArray docTypes = obj.getJSONArray("output");
            for (int i = 0; i < docTypes.length(); i++) {
                JSONObject jsonObject = docTypes.getJSONObject(i);
                if (jsonObject.getString("category").equalsIgnoreCase(docCategory)) {
                    listDocTypes.put(jsonObject.getString("document_type"), jsonObject.getString("input_date"));
                }
            }
        } catch (UnirestException | JSONException ex) {
            throw new Exception("Error in Creating Object Name - ErrMsg: " + ex);
        }

        String inputDate = listDocTypes.getOrDefault(docType, "false");

        if (inputDate.equalsIgnoreCase("false")) {
//            if user rek -> dok type identitas can be inserted in dok rekening
            if (isUserRek) {
                objNameNew = docType + "_" + docDate + "_" + docDesc;
            } else {
                throw new Exception("Error in Creating Object Name - Document Type Not Found in DEA");
            }
        } else if (inputDate.equalsIgnoreCase("doc_due_date")) {
            objNameNew = docType + "_" + docDueDate + "_" + docDesc;
        } else if (inputDate.equalsIgnoreCase("document_date")) {
            objNameNew = docType + "_" + docDate + "_" + docDesc;
        } else {
            throw new Exception("Error in Creating Object Name - Document Type Not Found in DEA");
        }
        return objNameNew;
    }

    public String getCustomerName(String cisNo, String restUrlEai, String clientId) throws IOException, UnirestException, Exception {
        String custName = null;
        try {
            final HttpResponse<JsonNode> response = Unirest.get(restUrlEai + cisNo + "?FunctionCode=04")
                    .header("ClientId", clientId)
                    .asJson();
            JSONObject obj = response.getBody().getObject();
            custName = obj.getJSONObject("OutputSchema").getJSONObject("CustomerNameAndPhone").getString("FullName");
        } catch (UnirestException | JSONException jsEx) {
            throw new Exception("Error in getCustomerName - ErrMsg: " + jsEx);
        }

        if ((custName.equals("") || custName.equals(" ")) || "".equals(custName.trim())) {
            throw new Exception("Customer Name Not Found for CIS " + cisNo + "!");
        }
        return custName;
    }

    public void checkDocType(String restURLDocType, String accessKey, String secretKey, String docType, String inputCategory, Boolean isUserRek) throws Exception {
        HashMap<String, String> mapDocTypes = new HashMap<>();

        try {
            final HttpResponse<JsonNode> response = Unirest.get(restURLDocType)
                    .header("AUTHORIZATION", accessKey + ":" + secretKey)
                    .asJson();
            JSONObject obj = response.getBody().getObject();
            JSONArray docTypes = obj.getJSONArray("output");
            for (int i = 0; i < docTypes.length(); i++) {
                JSONObject jsonObject = docTypes.getJSONObject(i);
                if (jsonObject.getString("category").equalsIgnoreCase(inputCategory)) {
                    mapDocTypes.put(jsonObject.getString("document_type"), jsonObject.getString("category"));
                }
            }
        } catch (UnirestException | JSONException ex) {
            throw new Exception("Error in checkDocType - ErrMsg: " + ex);
        }

        String category = mapDocTypes.getOrDefault(docType, null);
        if (category == null) {
//            pdc user exception
            if (isUserRek) {
                checkDocType(restURLDocType, accessKey, secretKey, docType, "IDENTITAS", false);
            } else {
                throw new Exception("Error - Document Type " + docType + " is not listed in " + inputCategory);
            }
        }
//        return category.equalsIgnoreCase(inputCategory.trim());
    }

    public String accNoUsageChecker(String inputCategory, String inputAccNo, String cisNo, String restUrlCisEAI, String clientId, ArrayList categoriesUsingAcc, ArrayList categoriesUsingAccOpt) throws Exception {
        String accNo = "";
        if (categoriesUsingAcc.contains(inputCategory.toLowerCase())) {
            accNo = accNoChecker(inputAccNo);
            if ("0000000000".equals(accNo)) {
                if (categoriesUsingAccOpt.contains(inputCategory.toLowerCase())) {
                    return accNo;
                } else {
                    throw new Exception("Account Number " + accNo + " Invalid!");
                }

            }

            if (!accNo.equals(tempAccNo)) {
                //if di folder no rek yang berbeda
                tempAccNo = accNo;

                if (checkAccNoFromCis(cisNo, tempAccNo, restUrlCisEAI, clientId) == false) {
                    isAccValid = false;
                    throw new Exception("Account No " + accNo + " not registered on Cis No : " + cisNo);
                } else {
                    isAccValid = true;
                }
            } else {
                //else di folder no rek yang sama
                if (isAccValid == false) {
                    throw new Exception("Account No " + accNo + " not registered on Cis No : " + cisNo);
                }
            }
        }
        return accNo;
    }

    public String branchCodeChecker(String branchCode) throws Exception {
        if ((branchCode.equals("") || branchCode.equals(" ")) || "".equals(branchCode.trim())) {
            throw new Exception("Branch Code Cannot Be Empty!");
        }

        if (branchCode.length() != 4) {
            throw new Exception("Branch Code " + branchCode + " Invalid!");
        }

        try {
            Long.parseLong(branchCode);
        } catch (NumberFormatException ex) {
            throw new Exception("Branch Code must be Numeric!" + ex);
        }

        return branchCode;
    }

    public String boxNumberChecker(String boxNumber) throws Exception {
        if ((boxNumber.equals("") || boxNumber.equals(" ")) || "".equals(boxNumber.trim())) {
            throw new Exception("Box Number Cannot Be Empty!");
        }

        if (boxNumber.length() > 30) {
            throw new Exception("Box Number " + boxNumber + " Length Invalid!");
        }

        return boxNumber;
    }
    
    public String docDescChecker(String docDesc) throws Exception {
        if (docDesc.length() > 120) {
            throw new Exception("Error - Doc Desc Length Max 120");
        }
        return docDesc.toUpperCase();
    }

    public String cisNoChecker(String cisNo, String REST_URL_EAI, String CLIENT_ID) throws Exception {
        if (cisNo == null || "".equals(cisNo.trim())) {
            throw new Exception("CIS Number " + cisNo + " cannot be empty");
        }

        try {
            Long.parseLong(cisNo);
        } catch (NumberFormatException ex) {
            throw new Exception("CIS Number must be Numeric!" + ex);
        }

        if (cisNo.length() > 11 && cisNo.charAt(0) != '0') {
            throw new Exception("CIS Number " + cisNo + " Invalid!");
        }

        cisNo = cisNo.replaceFirst("^0+(?!$)", "");
        cisNo = paddingZero(cisNo, 11);
        if (cisNo.length() > 11 || cisNo.equals("00000000000")) {
            throw new Exception("CIS Number " + cisNo + " Invalid!");
        }

        if (!cisNo.equals(tempCisNo)) {
            tempCisNo = cisNo;
            if ("success".equals(cisValidation(cisNo, REST_URL_EAI, CLIENT_ID).toLowerCase())) {
                isCisValid = true;
            } else {
                isCisValid = false;
                throw new Exception("CIS " + cisNo + " Not Valid!");
            }
        } else {
            //else CIS already checked before
            if (isCisValid == false) {
                throw new Exception("CIS " + cisNo + " Not Valid!");
            }
        }

        return cisNo;
    }

    public String accNoChecker(String accNo) throws Exception {
        if (accNo == null || accNo.equals("") || accNo.equals(" ") || accNo.trim().equals("")) {
            throw new Exception("Account No " + accNo + " Cannot Be Empty!");
        }

        try {
            Long.parseLong(accNo);
        } catch (NumberFormatException ex) {
            throw new Exception("Account Number must be Numeric!" + ex);
        }

        if (accNo.length() > 10 && accNo.charAt(0) != '0') {
            throw new Exception("Account Number " + accNo + " Invalid!");
        }

        accNo = accNo.replaceFirst("^0+(?!$)", "");
        accNo = paddingZero(accNo, 10);
//        if (accNo.length() > 10 || accNo.equals("0000000000")) {
        if (accNo.length() > 10) {
            throw new Exception("Account Number " + accNo + " Invalid!");
        }

        return accNo;
    }

    public String cisValidation(String cisNo, String restUrlEAI, String clientId) throws UnirestException, Exception {
        String resMsg = null;
        try {
            final HttpResponse<JsonNode> response = Unirest.get(restUrlEAI + cisNo + "?FunctionCode=04")
                    .header("ClientId", clientId)
                    .asJson();
            JSONObject obj = response.getBody().getObject();
            resMsg = obj.getJSONObject("ErrorSchema").getJSONObject("ErrorMessage").getString("English");
        } catch (UnirestException | JSONException ex) {
            throw new Exception("Error in cisValidation - ErrMsg: " + ex);
        }

        return resMsg;
    }

    public boolean checkAccNoFromCis(String cisNo, String accNo, String restUrlCisEAI, String clientId) throws UnirestException, Exception {
        HashMap<String, Boolean> listAccounts = new HashMap<>();
        boolean exist = true;
        try {
            final HttpResponse<JsonNode> response = Unirest.get(restUrlCisEAI + cisNo)
                    .header("client-id", clientId)
                    .asJson();
            JSONObject obj = response.getBody().getObject();
            JSONArray accounts = obj.getJSONObject("output_schema").getJSONArray("accounts");
            for (int i = 0; i < accounts.length(); i++) {
                JSONObject jsonObject = accounts.getJSONObject(i);
                String accountNo = jsonObject.getString("account_number");
                listAccounts.put(accountNo, true);
            }
        } catch (UnirestException | JSONException ex) {
            throw new Exception("Error in checkAccNoFromCis - ErrMsg: " + ex);
        }
//        System.out.println("listnya " +listAccounts);
        if (listAccounts.get(accNo) == null) {
            exist = false;
        }
        return exist;
    }

    public boolean checkFileSize(String fileLocation, String maxSize) throws IOException {
        Path filePath;
        int max = Integer.valueOf(maxSize); //26214400
        filePath = Paths.get(fileLocation);
        BasicFileAttributes attr = Files.readAttributes(filePath, BasicFileAttributes.class);
        return attr.size() <= max;
    }

}
