/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bca.main;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author U065626
 */
public class Rules {

    private final String SEPARATOR = System.getProperty("file.separator");
    private final String USER_PATH = Rules.class.getClassLoader().getResource("bca/main/Rules.class").getPath();
    private final String USER_DIR = USER_PATH.substring(USER_PATH.indexOf('/') + 1, USER_PATH.substring(0, USER_PATH.substring(0, USER_PATH.indexOf('.')).lastIndexOf('/')).lastIndexOf('/')).replace("/bca", "").replace("/", SEPARATOR);
    private final String RULES_DIR = USER_DIR + SEPARATOR + "RULES";
    private String rulesPathHCP = "/rest/uploadTools/rules";

    public static List<String> _RULES_DOC_DATE;
    public static List<String> _RULES_DUE_DATE;
    public static List<String> _RULES_KETERANGAN;
    public static List<String> _RULES_USER_REKENING;
    
    public static Map<String, ArrayList> docTypeMap;
    
    private Properties ruless;
    
    private void getRulesFromHCP(String bucketName, String endPoint, String accessKey, String secretKey) throws Exception {
        final HttpResponse<InputStream> response
                = Unirest.get("http://" + bucketName + "." + endPoint + this.rulesPathHCP)
                        .header("AUTHORIZATION", accessKey + ":" + secretKey)
                        .asBinary();
        String status = response.getStatus() + "";
        this.ruless = new Properties();
        this.ruless.load(response.getBody());
    }

    public static void readRules() throws IOException {
        Rules rules = new Rules();
        try {
            File categoryDocTypeList = new File(rules.RULES_DIR + rules.SEPARATOR + "category");
            docTypeMap = new HashMap<>();
            String categoryName;

            if (!categoryDocTypeList.exists()) {
                System.out.println("Folder " + categoryDocTypeList + " not exist");
                throw new IOException("Folder " + categoryDocTypeList + " not exist");        
            }
            // Get all files from folder.
            File[] listDocTypes = categoryDocTypeList.listFiles();
            for (int i = 0; i < listDocTypes.length; i++) {
                if (listDocTypes[i].isFile()) {
//                    System.out.println("File " + listDocTypes[i].getName());
                    categoryName = listDocTypes[i].getName().replaceFirst("[.][^.]+$", ""); // ex: IDENTITAS
                    String fullFilePath = rules.RULES_DIR + rules.SEPARATOR + "category" + rules.SEPARATOR + listDocTypes[i].getName();
                    String docTypes = new String(Files.readAllBytes(Paths.get(fullFilePath)));
                    List<String> catDocTypes = new ArrayList<>(Arrays.asList(docTypes.split(";")));
                    docTypeMap.put(categoryName.toUpperCase(), (ArrayList) catDocTypes);
                }
            }

            String DUEDATE_FILE = rules.RULES_DIR + rules.SEPARATOR + "DueDate.txt";
            String DOCDATE_FILE = rules.RULES_DIR + rules.SEPARATOR + "DocDate.txt";
            String KETERANGAN_FILE = rules.RULES_DIR + rules.SEPARATOR + "Keterangan.txt";
            String LIST_USER_REKENING_FILE = rules.RULES_DIR + rules.SEPARATOR + "ListUserRekening.txt";

            String dueDate = new String(Files.readAllBytes(Paths.get(DUEDATE_FILE)));
            String docDate = new String(Files.readAllBytes(Paths.get(DOCDATE_FILE)));
            String keterangan = new String(Files.readAllBytes(Paths.get(KETERANGAN_FILE)));
            String userRekeningList = new String(Files.readAllBytes(Paths.get(LIST_USER_REKENING_FILE)));

            _RULES_DUE_DATE = new ArrayList<>(Arrays.asList(dueDate.split(";")));
            _RULES_DOC_DATE = new ArrayList<>(Arrays.asList(docDate.split(";")));
            _RULES_KETERANGAN = new ArrayList<>(Arrays.asList(keterangan.split(";")));
            _RULES_USER_REKENING = new ArrayList<>(Arrays.asList(userRekeningList.split(";")));

        } catch (IOException ex) {
            throw new IOException("Error in readRules init, Msg: " + ex);
        }
    }
}
