/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bca.main;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import org.apache.log4j.Logger;
import org.json.JSONException;

/**
 *
 * @author U065626
 */
public class UploadToDEA {

    /**
     * @param args the command words arguments
     */
    private static final Logger LOGGER = Logger.getLogger(UploadToDEA.class);
    private static final String SEPARATOR = System.getProperty("file.separator");

    private static ConfigurationProperties props;
    private static DataValidation dataValidation;
    private static ExtractMetadata extract;
    private static String errorMessage;
    private static String errorUploadMessage;
    private static int statusImport;

    private static void writeFile(String filePath, String line) {
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(filePath, true);
            byte[] strToBytes = line.getBytes();
            outputStream.write(strToBytes);
            outputStream.close();

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {

        }
    }

    public static String insertMetadataToDEA(String restUrl, String cisNum, String accNo, String custName, String docDate, String docDueDate, String docType,
            String docDesc, String boxNum, String branchNo, String contentType, String product, String sourceFile, int status, int currentLine) throws IOException, UnirestException, Exception {
        String objId = "";
        HttpResponse<JsonNode> response = null;

        try {
            response = Unirest.post(restUrl)
                    .header("AUTHORIZATION", props.ACCESS_KEY + ":" + props.SECRET_KEY)
                    //                .field("OBJECT_ID", objId)
                    .field("APPROVAL", 3)
                    .field("CIS_NUMBER", cisNum)
                    .field("ACCOUNT_NUMBER", accNo)
                    .field("CUSTOMER_NAME", custName)
                    .field("DOCUMENT_DATE", docDate)
                    .field("DOC_DUE_DATE", docDueDate)
                    .field("DOCUMENT_TYPE", docType)
                    .field("DOCUMENT_DESC", docDesc)
                    .field("BOX_NUMBER", boxNum)
                    .field("BRANCH_NUMBER", branchNo)
                    .field("A_CONTENT_TYPE", contentType)
                    .field("PRODUCT", product)
                    //                .field("URLPATH", urlPath)
                    .field("SET_FILE", sourceFile)
                    .field("p_status", status)
                    .asJson();
            statusImport = response.getStatus();
        } catch (UnirestException ex) {
            LOGGER.error("Import Metadata Failed, Error Msg: " + ex.getMessage());
            errorMessage = ex.getMessage();
            throw new Exception(ex);
        }
        if (statusImport == 200) {
            objId = response.getBody().getObject().get("object_id").toString();
            return objId;
        } else {
            errorMessage = response.getBody().getObject().get("error_message_english").toString();
            return null;
        }
    }

    public static int insert_file(String object_id, String sourceFile) throws IOException, UnirestException {
        int status = 0;
        HttpResponse<InputStream> response = null;

        try {
            response = Unirest.post(props.REST_URL_FILE + "?R_OBJECT_ID=" + object_id)
                    .header("AUTHORIZATION", props.ACCESS_KEY + ":" + props.SECRET_KEY)
                    .body(Files.readAllBytes(Paths.get(sourceFile))) //file yang akan diinput
                    .asBinary();
            status = response.getStatus();
        } catch (UnirestException | IOException x) {
            LOGGER.error("File on object id: " + object_id + " fails uploaded..! Error code: " + x);
            System.out.println(x.getMessage());
        }

        if (status != 200) {
            errorUploadMessage = response.getStatusText();
        }
        return status;
    }

//    public static int insert_file(String object_id, String sourceFile)	
//    throws IOException, UnirestException	
//  {	
//    return Unirest.post(props.REST_URL_FILE + "?R_OBJECT_ID=" + object_id)	
//      .header("AUTHORIZATION", ConfigurationProperties.ACCESS_KEY + ":" + ConfigurationProperties.SECRET_KEY)	
//      .body(Files.readAllBytes(Paths.get(sourceFile, new String[0])))	
//      .asBinary()	
//      .getStatus();
//  }
    private static boolean deleteFile(String localFile) throws InterruptedException {
        boolean isDelete = true;
        if (localFile.equals(props.mainFolder)) {
//            System.out.println("Ends on Main Folder");
        } else if (!localFile.equals(props.mainFolder)) {
            File f = new File(localFile);
//            System.out.println("Deleting " + f);
            if (f.exists()) {
//                System.out.println("listnya " + Arrays.toString(f.list()));
                if (f.isFile() || f.list().length < 1) {
                    if (f.delete()) {
//                        Thread.sleep(1);
                        deleteFile(f.getParent());
                    }
                }
            }
        }

        return isDelete;
    }

    private static boolean doDeleteFolder(File dir) throws InterruptedException {
        if (dir.isDirectory() && dir.exists()) {
            String[] children = dir.list();
//                Thread.sleep(5);
            for (int i = 0; i < children.length; i++) {
//                    System.out.println("children: " + Arrays.toString(dir.list()));
                boolean success = doDeleteFolder(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // The directory is now empty so delete it
        return dir.delete();
    }

    private static void sendEmail(String message) throws Exception {
//        TODO: penjagaan di Emailer
        if ("".equals(props.to) && props.to.length() == 0) {
            throw new Exception("'to' cannot be empty");
        }
        if ("".equals(props.cc) && props.cc.length() == 0) {
            throw new Exception("'cc' cannot be empty");
        }
        if ("".equals(props.SMTPAddress) && props.SMTPAddress.length() == 0) {
            throw new Exception("'SMTPAddress' cannot be empty");
        }

        try {
            String[] tos = props.to.split(";");
            String[] ccs = props.cc.split(";");
            Emailer.sendMail(props.SMTPAddress, props.from, tos, ccs, props.subject, message, false);
        } catch (Exception ex) {
            throw new Exception("Error! -- Cannot send email, Error Msg : " + ex.getMessage());
        }
    }

    public static void main(String[] args) throws IOException, Exception {

        System.out.println("USER_DIR: " + System.getProperty("user.dir"));
        dataValidation = new DataValidation();

        int currentLine = 0;
        int successLine = 0;
        int successLineFile = 0;
        int failedLine = 0;
        int failedLineFile = 0;

        String restAPI = "";

        String objId = "";
        String localFile = "";
        String fileType = "";
        String cisNo;
        String accNo;
        String docCategory = "";
        String docDueDate = "";
        String docDate = "";
        String docDesc = "";
        String branchCode;
        String custName = "";
        String productName = "";
        String boxNo = "";
        String docType = "";
        String contentType = "";

        int numberOfFiles = 0;

        FileInputStream source = null;
        BufferedReader br = null;

        Date startDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        System.out.println(formatter.format(startDate) + " - Starting ImportPDCtoDEA Version " + "4.0" + "..");
        LOGGER.debug(formatter.format(startDate) + " - Starting ImportPDCtoDEA Version " + "4.0" + "..");

        try {
//          important!!
            props = new ConfigurationProperties("");
            System.out.println(formatter.format(startDate) + " - Config Version " + props.VERSION + "..");
            LOGGER.debug(formatter.format(startDate) + " - Config Version " + props.VERSION + "..");
//            Rules.readRules();
            extract = new ExtractMetadata();
            extract.extracting(props);

            System.out.println(formatter.format(startDate) + " - Starting Import Metadata on UploadDEA..");
            LOGGER.debug(formatter.format(startDate) + " - Starting Import Metadata on UploadDEA..");
            String filePath = ConfigurationProperties.PROCESS_DIR + SEPARATOR + props.processFile;
            File file = new File(filePath);
            if (!file.exists()) {
                throw new Exception("File '" + filePath + "' Not Found..!");
            }
            source = new FileInputStream(filePath);
            br = new BufferedReader(new InputStreamReader(source));
            String str;
            String lineHeader = "";
            String newLine = "";
            int statusUpload = 0;

//            System.out.println("list: " + new File(props.mainFolder).list().length);
            while ((str = br.readLine()) != null) {
                try {
                    String[] words = str.split(props.delimiter);
                    if (currentLine == 0 && words[0].toLowerCase().equals("localpath")) {
                        lineHeader = str;
                        writeFile(ConfigurationProperties.RESULT_FILE_SUCCESS, "r_object_id;" + lineHeader + ";status_import\n");
                        writeFile(ConfigurationProperties.RESULT_FILE_ERROR, lineHeader + ";status_import;error_msg\n");
                        writeFile(ConfigurationProperties.RESULT_FILE_UPLOAD_SUCCESS, "r_object_id;" + lineHeader + ";status_upload\n");
                        writeFile(ConfigurationProperties.RESULT_FILE_UPLOAD_ERROR, "r_object_id;" + lineHeader + ";status_upload;error_msg\n");
                    } else {

                        localFile = words[0];
                        if (!new File(localFile).exists()) {
                            throw new FileNotFoundException(localFile + " Not Found!");
                        }

                        contentType = words[1].toUpperCase();
//                        objName = words[4];
                        cisNo = words[2];
                        accNo = words[3];
                        if ("0000000000".equals(accNo)) {
                            accNo = "";
                        }
                        docType = words[4];
                        docCategory = words[5];
                        docDueDate = dataValidation.checkDate(words[6]);
                        docDate = dataValidation.checkDate(words[7]);
                        docDesc = words[8];
                        branchCode = words[9];
                        custName = words[10];
                        productName = words[11];
                        boxNo = words[12];

//                        objNameNew = dataValidation.changeObjName(docType, docDueDate, docDate, docDesc);
                        newLine = ";" + localFile + ";" + contentType + ";" + cisNo + ";" + accNo + ";" + docType + ";" + docCategory + ";" + docDueDate + ";" + docDate + ";" + docDesc + ";" + branchCode + ";" + custName + ";" + productName + ";" + boxNo;

                        if (props.categoriesAPI.containsKey(docCategory.toLowerCase().trim()) == false) {
                            throw new Exception("Document Category '" + docCategory + "' not valid..! Category Not Set in Config");
                        }

                        restAPI = props.categoriesAPI.get(docCategory.toLowerCase().trim());
                        objId = insertMetadataToDEA(restAPI, cisNo, accNo, custName, docDate, docDueDate, docType, docDesc, boxNo, branchCode, contentType, productName, "", 0, currentLine);

                        if (statusImport == 200 && !objId.isEmpty()) {
                            successLine++;
                            LOGGER.debug("Line " + currentLine + ", object id: " + objId + " successfully imported..!");
                            writeFile(ConfigurationProperties.RESULT_FILE_SUCCESS, objId + newLine + ";" + statusImport + "\n");

                            statusUpload = insert_file(objId, localFile);
                            if (statusUpload == 200) {
                                LOGGER.debug("File on Line " + currentLine + ", object id: " + objId + " successfully uploaded..!");
                                writeFile(ConfigurationProperties.RESULT_FILE_UPLOAD_SUCCESS, objId + newLine + ";" + statusUpload + "\n");
                                successLineFile++;

                                //count success file each category
                                int temp = props.categoriesName.get(docCategory.toLowerCase());
                                props.categoriesName.put(docCategory.toLowerCase(), ++temp);

                                if (new File(localFile).exists()) {
                                    boolean doDeleteFolder = deleteFile(localFile);
                                }

                            } else {
                                LOGGER.error("File on Line " + currentLine + ", object id: " + objId + " fails uploaded..! Error code: " + statusUpload + ", " + errorUploadMessage);
                                LOGGER.debug("File on Line " + currentLine + ", object id: " + objId + " fails uploaded..! Error code: " + statusUpload + ", " + errorUploadMessage);
                                writeFile(ConfigurationProperties.RESULT_FILE_UPLOAD_ERROR, objId + newLine + ";" + statusUpload + ";" + errorUploadMessage + "\n");
                                failedLineFile++;
                            }

                        } else {
                            LOGGER.error("Document on Line " + currentLine + " fails imported..! Error code: " + statusImport + ", " + errorMessage);
                            LOGGER.debug("Document on Line " + currentLine + " fails imported..! Error code: " + statusImport + ", " + errorMessage);
                            failedLine++;
                            writeFile(ConfigurationProperties.RESULT_FILE_ERROR, str + ";" + statusImport + ";" + errorMessage + "\n");
                        }
                        currentLine++;
                    }
                } catch (NumberFormatException ex) {
//                    mengandung numberformatexception
                    LOGGER.error("Number Format Exception on Line '" + currentLine + "' - objId '" + objId + "', " + ex.getMessage());
                    writeFile(ConfigurationProperties.RESULT_FILE_ERROR, str + ";" + statusImport + ";" + ex + "\n");
                    failedLine++;
                } catch (Exception inEx) {
                    LOGGER.error("Inner Exception on Line '" + currentLine + "' - objId '" + objId + "', " + inEx.getMessage());
                    writeFile(ConfigurationProperties.RESULT_FILE_ERROR, str + ";" + statusImport + ";" + inEx + "\n");
                    failedLine++;
                }
            }

//                doDeleteFolder(new File(props.mainFolder));
        } catch (Exception x) {
            LOGGER.error("Error on Main Program, Msg: " + x.getMessage());
            System.out.println("Error on Main Program, Msg: " + x.getMessage());
        } finally {
            if (br != null) {
                br.close();
            }
            if (source != null) {
                source.close();
            }
            Unirest.shutdown();
        }

        if (currentLine > 0) {

            Date endDate = new Date();
            System.out.println(formatter.format(endDate) + " - Finish Program, Total Line(s): " + currentLine);
            System.out.println(formatter.format(endDate) + " - Import Metadata, Success " + successLine + ", Fail " + failedLine);
            System.out.println(formatter.format(endDate) + " - Upload File, Success " + successLineFile + ", Fail " + failedLineFile);
            System.out.println(formatter.format(endDate) + " - " + props.categoriesName);

            LOGGER.debug(formatter.format(endDate) + " - Finish Program, Total Line(s): " + currentLine);
            LOGGER.debug(formatter.format(endDate) + " - Import Metadata, Success " + successLine + ", Fail " + failedLine);
            LOGGER.debug(formatter.format(endDate) + " - Upload File, Success " + successLineFile + ", Fail " + failedLineFile);
            LOGGER.debug(formatter.format(endDate) + " - " + props.categoriesName);

            System.out.println("Sending email notification");
            LOGGER.debug("Sending email notification");
            String msgSummary = "Total Dokumen: " + currentLine
                    + "<br><br>Sukses Import Metadata: " + successLine + "<br>Gagal Import Metadata: "
                    + failedLine + "<br><br>Sukses Upload File: " + successLineFile
                    + "<br>Gagal Upload File: " + failedLineFile
                    + "<br>File Berhasil Import dan Upload: " + props.categoriesName;

            try {
                sendEmail(msgSummary);
            } catch (Exception e) {
                LOGGER.debug("Fail to send email notification, Exception: " + e);
            }

        }

    }

}
