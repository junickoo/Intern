/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bca.main;

/**
 *
 * @author U065626
 */

import com.sun.istack.internal.ByteArrayDataSource;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Emailer {
    /*send single email*/
    public static void sendMail(String smtpAdress, String from, String to[], String cc[], String subject, String message, boolean debug) throws Exception {

        //Set the host smtp address
        Properties props = new Properties();
        props.put("mail.smtp.host", smtpAdress);

        // create some properties and get the default Session
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(debug);

        // create a message
        Message msg = new MimeMessage(session);

        try {
            // set the from and to address
            InternetAddress addressFrom = new InternetAddress(from);
            msg.setFrom(addressFrom);

            InternetAddress[] addressTo = new InternetAddress[to.length];
            InternetAddress[] addressCc = new InternetAddress[cc.length];
            for (int i = 0; i < to.length; i++) {
                addressTo[i] = new InternetAddress(to[i]);
            }
            for (int i = 0; i < cc.length; i++) {
                addressCc[i] = new InternetAddress(cc[i]);
            }
            msg.setRecipients(Message.RecipientType.TO, addressTo);
            msg.setRecipients(Message.RecipientType.CC, addressCc);

            // Setting the Subject and Content Type
            msg.setSubject(subject);
            msg.setContent(message, "text/html");
            Transport.send(msg);
        } catch (Exception ex) {
            throw new Exception("Send Email failed.");
        }
    }

    
    /**
     * Send a email with multiple attachment (bytes).
     */
    public static void sendMail(String smtpAdress, String from, byte[] successContent, byte[] failedContent, String successFile, String failedFile, 
            String to[], String cc[], String subject, String message, boolean debug) throws Exception {

        //Set the host smtp address
        Properties props = new Properties();
        props.put("mail.smtp.host", smtpAdress);

        // create some properties and get the default Session
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(debug);
        try {
            InternetAddress addressFrom = new InternetAddress(from);
            InternetAddress[] addressTo = new InternetAddress[to.length];
            InternetAddress[] addressCc = new InternetAddress[cc.length];
            for (int i = 0; i < to.length; i++) {
                addressTo[i] = new InternetAddress(to[i]);
            }
            for (int i = 0; i < cc.length; i++) {
                addressCc[i] = new InternetAddress(cc[i]);
            }

            // create a message
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(addressFrom);
            msg.setRecipients(Message.RecipientType.TO, addressTo);
            msg.setRecipients(Message.RecipientType.CC, addressCc);
            msg.setSubject(subject);
            msg.setSentDate(new Date());

            //add message in email
            MimeBodyPart messagePart = new MimeBodyPart();
            messagePart.setText(message);
            Multipart mp = new MimeMultipart();
            mp.addBodyPart(messagePart);
            
            MimeBodyPart attachmentFile = null;
            ByteArrayDataSource ds = null;
         
            if (successContent.length > 0) {
                attachmentFile = new MimeBodyPart();
                ds = new ByteArrayDataSource(successContent, "application/pdf");
                attachmentFile.setDataHandler(new DataHandler(ds));
                attachmentFile.setFileName(successFile);
                mp.addBodyPart(attachmentFile);
            }

            if (failedContent.length > 0) {
                attachmentFile = new MimeBodyPart();
                ds = new ByteArrayDataSource(failedContent, "application/pdf");
                attachmentFile.setDataHandler(new DataHandler(ds));
                attachmentFile.setFileName(failedFile);
                mp.addBodyPart(attachmentFile);
            }


            msg.setContent(mp);
            Transport.send(msg);
        } catch (Exception ex) {
            throw new Exception("Send Email with attachment failed.");
        }
    }
    
    /**
     * Send a email with multiple attachment (file).
     */
    public static void sendMail(String smtpAdress, String from, ArrayList<File> listFile, String to[], String cc[], String subject, String message, boolean debug) throws Exception {

        //Set the host smtp address
        Properties props = new Properties();
        props.put("mail.smtp.host", smtpAdress);

        // create some properties and get the default Session
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(debug);
        try {
            InternetAddress addressFrom = new InternetAddress(from);
            InternetAddress[] addressTo = new InternetAddress[to.length];
            InternetAddress[] addressCc = new InternetAddress[cc.length];
            for (int i = 0; i < to.length; i++) {
                addressTo[i] = new InternetAddress(to[i]);
            }
            for (int i = 0; i < cc.length; i++) {
                addressCc[i] = new InternetAddress(cc[i]);
            }

            // create a message
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(addressFrom);
            msg.setRecipients(Message.RecipientType.TO, addressTo);
            msg.setRecipients(Message.RecipientType.CC, addressCc);
            msg.setSubject(subject);
            msg.setSentDate(new Date());

            //add message in email
            MimeBodyPart messagePart = new MimeBodyPart();
            messagePart.setText(message);
            Multipart mp = new MimeMultipart();
            mp.addBodyPart(messagePart);
            
            for (int i = 0; i < listFile.size(); i++) {
                MimeBodyPart attachmentFile = new MimeBodyPart();
                FileDataSource fdsSuccess = new FileDataSource(listFile.get(i));
                attachmentFile.setDataHandler(new DataHandler(fdsSuccess));
                attachmentFile.setFileName(fdsSuccess.getName());
                mp.addBodyPart(attachmentFile);
            }

            msg.setContent(mp);
            Transport.send(msg);
        } catch (Exception ex) {
            throw new Exception("Send Email with attachment failed.");
        }
    }
}
