/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bca.main;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import java.util.Base64;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author U065626
 */
public class ConfigurationProperties {

    private static final Logger LOGGER = Logger.getLogger(UploadToDEA.class);
    protected static final String SEPARATOR = System.getProperty("file.separator");

//    config paths
    public static final String USER_PATH = ConfigurationProperties.class.getClassLoader().getResource("bca/main/ConfigurationProperties.class").getPath();
    public static final String USER_DIR = USER_PATH.substring(USER_PATH.indexOf('/') + 1, USER_PATH.substring(0, USER_PATH.substring(0, USER_PATH.indexOf('.')).lastIndexOf('/')).lastIndexOf('/')).replace("/bca", "").replace("/", SEPARATOR);
    public static final String PROCESS_DIR = USER_DIR + SEPARATOR + "PROCESS";
    public static final String RESULT_DIR = USER_DIR + SEPARATOR + "RESULT";
    public static final String RESULT_FILE_SUCCESS = RESULT_DIR + SEPARATOR + "ImportMetadataSuccess.csv";
    public static final String RESULT_FILE_ERROR = RESULT_DIR + SEPARATOR + "ImportMetadataError.csv";
    public static final String RESULT_FILE_UPLOAD_SUCCESS = RESULT_DIR + SEPARATOR + "UploadFileSuccess.csv";
    public static final String RESULT_FILE_UPLOAD_ERROR = RESULT_DIR + SEPARATOR + "UploadFileError.csv";

    private String CONFIG_ADDRESS;
    private String CONFIG_PROPERTIES;
    private String configPathHCP;

//    config values
    public String VERSION;
    public String MAXSIZE;
    
    public String AUTHORIZATION_ADMIN;
    public static String ACCESS_KEY;
    public String UDOMAIN;
    public static String SECRET_KEY;

    public String REST_URL_GET_USER;
    public String REST_URL_FILE;
    public String REST_URL_EAI;
    public String REST_URL_EAI_CIS;
//    public String REST_URL_EAI_CIS_PARAMS;
    public String REST_URL_DEA_DOCUMENTTYPE;

    public String IP_PORT_DEA;
    public String IP_PORT_EAI;
    public String PATH_DEA;
    public String PATH_HCP;
    
    public String END_POINT;
    public String BUCKET_NAME;
    public String ACCESS_KEY_FILE;
    public String SECRET_KEY_FILE;

    public String mainFolder;
    public String CLIENT_ID;
    public String delimiter;
    public String processFile;
    public ArrayList<String> ignoreExtList;
    public ArrayList<String> userRekening;
    public ArrayList<String> categoriesUsingAcc;
    public ArrayList<String> categoriesUsingAccOpt;
    public Map<String, String> categoriesLength;
    public Map<String, Integer> categoriesName;
    public Map<String, String> categoriesAPI;

    //for custom report
    public String SMTPAddress;
    public String to;
    public String from;
    public String cc;
    public String subject;
    public String currentDate;
    public String fileNameSuccess;
    public String fileNameFailed;
    public String fileExtension;

    private Properties props;
    private Properties propss;

    public ConfigurationProperties(String configFileName) throws Exception {
        this.CONFIG_ADDRESS = USER_DIR + SEPARATOR + "config" + SEPARATOR;

        if (configFileName == null || "".equals(configFileName)) {
            this.CONFIG_PROPERTIES = CONFIG_ADDRESS + "config.properties";
        } else {
            this.CONFIG_PROPERTIES = CONFIG_ADDRESS + configFileName;
        }
        System.out.println(System.getProperty("user.name"));
        this.readProperties();
        this.populateProps();
        this.readPropertiesFromHCP();
        this.populatePropsHCP();
        checkUserDomain();
    }

    private void readProperties() throws Exception {
        try {
            LOGGER.debug("Read file config " + this.CONFIG_PROPERTIES + " ..");
            this.props = new Properties();
            this.props.load(new FileInputStream(this.CONFIG_PROPERTIES));
        } catch (IOException fnfe) {
            throw new Exception(fnfe);
        }
    }

    private void readPropertiesFromHCP() throws Exception {
//        HTTP ditaro di config bucketname
        final HttpResponse<InputStream> response
                = Unirest.get(this.BUCKET_NAME + "." + this.END_POINT + this.configPathHCP)
                        .header("AUTHORIZATION", this.ACCESS_KEY_FILE + ":" + this.SECRET_KEY_FILE)
                        .asBinary();
        String status = response.getStatus() + "";
        this.propss = new Properties();
        this.propss.load(response.getBody());
    }

    private String getConfigPropertiesValue(String key) throws Exception {
        String value = this.props.getProperty(key);
        if (value == null || value.equals("")) {
            throw new Exception("getConfigPropertiesValue Key '" + key + "': 'Null or No Value'");
        } else {
            LOGGER.debug("Getting Value for Key '" + key + "' : '" + value + "'");
            return value;
        }
    }

    private String getConfigPropertiesValueFromHCP(String key) throws Exception {
        String value = this.propss.getProperty(key);
        if (value == null || value.equals("")) {
            throw new Exception("getConfigPropertiesValueFromHCP Key '" + key + "': 'Null or No Value'");
        } else {
            LOGGER.debug("Getting Value From HCP for Key '" + key + "' : '" + value + "'");
            return value;
        }
    }

    private void populateProps() throws Exception {
        LOGGER.info("Get Configuration Local '" + CONFIG_PROPERTIES + "' ..");
//        ignoreExtList = new ArrayList<>();
        try {

            this.UDOMAIN = getConfigPropertiesValue("USER_NAME").split(":")[0];
            this.ACCESS_KEY = getConfigPropertiesValue("USER_NAME").split(":")[1];
            this.configPathHCP = getConfigPropertiesValue("configPathHCP");
            this.END_POINT = getConfigPropertiesValue("END_POINT");
            this.BUCKET_NAME = getConfigPropertiesValue("BUCKET_NAME");
            this.ACCESS_KEY_FILE = getConfigPropertiesValue("ACCESS_KEY_FILE");
            this.SECRET_KEY_FILE = getConfigPropertiesValue("SECRET_KEY_FILE");

            this.mainFolder = getConfigPropertiesValue("mainFolder");

        } catch (Exception ex) {
            throw new Exception("Error in initConfigLocal, Msg: " + ex);
        }
    }

    private void populatePropsHCP() throws Exception {
        LOGGER.info("Get Configuration from HCP '" + configPathHCP + "' ..");
        ignoreExtList = new ArrayList<>();
        userRekening = new ArrayList<>();
        categoriesUsingAcc = new ArrayList<>();
        categoriesLength = new HashMap<>();
        categoriesAPI = new HashMap<>();
        categoriesName = new HashMap<>();
        categoriesUsingAccOpt = new ArrayList<>();
        try {
            this.VERSION = getConfigPropertiesValueFromHCP("VERSION");
            this.MAXSIZE = getConfigPropertiesValueFromHCP("MAXSIZE");
            
            this.AUTHORIZATION_ADMIN = getConfigPropertiesValueFromHCP("AUTHORIZATION_ADMIN");
            this.CLIENT_ID = getConfigPropertiesValueFromHCP("CLIENT_ID");
            this.SECRET_KEY = getConfigPropertiesValueFromHCP("SECRET_KEY");
            
            this.IP_PORT_DEA = getConfigPropertiesValueFromHCP("IP_PORT_DEA");
            this.IP_PORT_EAI = getConfigPropertiesValueFromHCP("IP_PORT_EAI");
            
            this.PATH_DEA = getConfigPropertiesValueFromHCP("PATH_DEA");
            this.PATH_HCP = getConfigPropertiesValueFromHCP("PATH_HCP");

            this.REST_URL_GET_USER = this.IP_PORT_DEA + this.PATH_DEA + getConfigPropertiesValueFromHCP("REST_URL_GET_USER");
            this.REST_URL_FILE = this.IP_PORT_DEA + this.PATH_DEA + getConfigPropertiesValueFromHCP("REST_URL_FILE");
            this.REST_URL_EAI = this.IP_PORT_EAI + getConfigPropertiesValueFromHCP("REST_URL_EAI");
            this.REST_URL_EAI_CIS = this.IP_PORT_EAI + getConfigPropertiesValueFromHCP("REST_URL_EAI_CIS");
//            this.REST_URL_EAI_CIS_PARAMS = getConfigPropertiesValueFromHCP("REST_URL_EAI_CIS_PARAMS");
            this.REST_URL_DEA_DOCUMENTTYPE = this.IP_PORT_DEA + this.PATH_DEA + getConfigPropertiesValueFromHCP("REST_URL_DEA_DOCUMENTTYPE");

            this.delimiter = getConfigPropertiesValueFromHCP("delimiter");
            this.processFile = getConfigPropertiesValueFromHCP("processFile");

            this.SMTPAddress = getConfigPropertiesValueFromHCP("SMTPAddress");
            this.from = getConfigPropertiesValueFromHCP("from");
            this.cc = getConfigPropertiesValueFromHCP("cc");
            this.subject = getConfigPropertiesValueFromHCP("subject");
            SimpleDateFormat sdf = new SimpleDateFormat(getConfigPropertiesValueFromHCP("dateFormat"));
            this.currentDate = sdf.format(java.util.Calendar.getInstance().getTime());
            this.to = getConfigPropertiesValueFromHCP("to");

            this.fileNameSuccess = getConfigPropertiesValueFromHCP("fileNameSuccess");
            this.fileNameFailed = getConfigPropertiesValueFromHCP("fileNameError");
            this.fileExtension = getConfigPropertiesValueFromHCP("fileExtension");

            String[] categoryName = getConfigPropertiesValueFromHCP("categoryName").split(",");
            String[] categoryLength = getConfigPropertiesValueFromHCP("categoryLength").split(",");
            String[] categoryAPI = getConfigPropertiesValueFromHCP("categoryAPI").split(",");

            
            
            if (categoryLength.length != categoryName.length) {
                throw new Exception("Error in initConfigHCP, Msg: Length of categoryName and categoryLength not equal");
            }
            
            if (categoryAPI.length != categoryName.length) {
                throw new Exception("Error in initConfigHCP, Msg: Length of categoryName and categoryAPI not equal");
            }
            
            for (int i = 0; i < categoryName.length; i++) {
                categoriesName.put("dokumen "+ categoryName[i], 0);
                categoriesLength.put(categoryName[i], categoryLength[i]);
            }
            
            for (int i = 0; i < categoryAPI.length; i++) {
                categoriesAPI.put("dokumen "+ categoryName[i], this.IP_PORT_DEA + this.PATH_DEA + categoryAPI[i]);
                LOGGER.debug("Setting REST URL for " + "dokumen "+ categoryName[i] + " : '" + this.IP_PORT_DEA + this.PATH_DEA + categoryAPI[i] + "'");
            }
            

            String arrIgnoreExt[] = getConfigPropertiesValueFromHCP("ignoreExtList").split(",");
            for (String arrIgnoreExt1 : arrIgnoreExt) {
                ignoreExtList.add(arrIgnoreExt1.toLowerCase());
            }
            
            String arrUser[] = getConfigPropertiesValueFromHCP("UserRekening").split(",");
            for (String arrUser1 : arrUser) {
                userRekening.add(arrUser1.toLowerCase());
            }
            
            String arrCategoryUsingAcc[] = getConfigPropertiesValueFromHCP("categoryUsingAcc").split(",");
            for (String arrCategoryUsingAcc1 : arrCategoryUsingAcc) {
                categoriesUsingAcc.add(arrCategoryUsingAcc1.toLowerCase());
            }
            
            String arrCategoryUsingAccOpt[] = getConfigPropertiesValueFromHCP("categoryRekOptional").split(",");
            for (String arrCategoryUsingAccOpt1 : arrCategoryUsingAccOpt) {
                categoriesUsingAccOpt.add(arrCategoryUsingAccOpt1.toLowerCase());
            }
            
        } catch (Exception ex) {
            throw new Exception("Error in initConfigHCP, Msg: " + ex);
        }
    }

    public boolean checkAuthorization() throws IOException, UnirestException, Exception {
        boolean active = false;
        int status = 0;
//        String accessKeyMetadata = Base64.base64Decode(this.ACCESS_KEY);
        
        try {
            String accessKeyMetadata = new String(Base64.getDecoder().decode(this.ACCESS_KEY), "UTF-8");
            final HttpResponse<JsonNode> response = Unirest.get(this.REST_URL_GET_USER + accessKeyMetadata)
                    .header("Authorization", this.AUTHORIZATION_ADMIN)
                    .asJson();
            JSONObject obj;
            obj = response.getBody().getObject();
            status = response.getStatus();
            if (status == 404){
                throw new Exception("Error in checkAuthorization init, User Authorization Not Found");
            }
            JSONArray output = obj.getJSONArray("output");
            JSONObject userDetailObj = output.getJSONObject(0);
            int userState = userDetailObj.getInt("user_state");

            if (userState == 1) {
                active = true;
            }
        } catch (UnirestException | JSONException x) {
            throw new Exception("Error in checkAuthorization init, Msg: " + x);
        }
        return active;
    }

    public boolean checkUserRekening() throws UnsupportedEncodingException {
        String accessKeyMetadata = new String(Base64.getDecoder().decode(this.ACCESS_KEY), "UTF-8");
        return this.userRekening.contains(accessKeyMetadata.toLowerCase());
    }
    
    public final void checkUserDomain() throws Exception {
        String user = new String(Base64.getDecoder().decode(this.UDOMAIN), "UTF-8");
        if(!System.getProperty("user.name").equalsIgnoreCase(user)){
            System.out.println("this user: " + user);
            throw new Exception("Error in checkUserDomain, "+System.getProperty("user.name")+" is not registered with the Auth Code, User on Code: " +user);
        };
    }

//    public static void initUploadFile() {
//
//        Unirest unirest = new Unirest();
//        unirest.setDefaultHeader(to, to);
//
//        Unirest.setDefaultHeader("AUTHORIZATION", ACCESS_KEY_FILE + ":" + SECRET_KEY_FILE);
//    }
//
//    public static void initImportMetadata() {
//        String accessKeyMetadata = Base64.getEncoder().encodeToString(ACCESS_KEY.getBytes());
//        Unirest.setDefaultHeader("AUTHORIZATION", accessKeyMetadata + ":" + SECRET_KEY);
//    }
}
